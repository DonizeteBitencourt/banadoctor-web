import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function UploadPage() {
  const [image, setImage] = useState(null);
  const navigate = useNavigate();

  const handleImageChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleSubmit = () => {
    if (image) {
      navigate('/result', { state: { image } });
    }
  };

  return (
    <div className="container">
      <h2>Enviar Foto</h2>
      <input type="file" accept="image/*" onChange={handleImageChange} />
      <button className="button" onClick={handleSubmit}>Analisar</button>
    </div>
  );
}

export default UploadPage;