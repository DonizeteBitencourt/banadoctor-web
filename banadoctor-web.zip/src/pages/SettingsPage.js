import React from 'react';

function SettingsPage() {
  return (
    <div className="container">
      <h2>Configurações</h2>
      <p>Idioma: Português</p>
      <p>Sobre: BanaDoctor v1.0</p>
    </div>
  );
}

export default SettingsPage;