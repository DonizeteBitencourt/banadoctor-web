import React from 'react';

function HistoryPage() {
  return (
    <div className="container">
      <h2>Histórico de Análises</h2>
      <p>(Histórico vazio no momento)</p>
    </div>
  );
}

export default HistoryPage;