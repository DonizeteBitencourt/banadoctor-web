import React from 'react';
import { useLocation, Link } from 'react-router-dom';

function ResultPage() {
  const location = useLocation();
  const { image } = location.state || {};

  return (
    <div className="container">
      <h2>Resultado do Diagnóstico</h2>
      {image && <img src={URL.createObjectURL(image)} alt="Enviado" className="uploaded-image" />}
      <h3>Diagnóstico: Sigatoka Negra</h3>
      <p>Solução: Aplicar fungicida sistêmico e remover folhas infectadas.</p>

      <Link to="/upload" className="button">🔄 Nova Análise</Link>
      <Link to="/history" className="button">💾 Salvar Resultado</Link>
    </div>
  );
}

export default ResultPage;