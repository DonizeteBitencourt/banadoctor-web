import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div className="container">
      <h1>BanaDoctor</h1>
      <Link to="/upload" className="button">📷 Enviar Foto</Link>
      <Link to="/history" className="button">📜 Ver Histórico</Link>
      <Link to="/settings" className="settings-link">⚙️ Configurações</Link>
    </div>
  );
}

export default HomePage;